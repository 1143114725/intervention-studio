package com.investigate.newsupper.base;

/**
 * 通用接口基类
 * @author EraJieZhang
 * @data 2018/11/23
 */
public interface BaseInterface {
    public void onNext();
    public void onError();

}
