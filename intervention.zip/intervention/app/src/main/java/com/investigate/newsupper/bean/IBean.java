package com.investigate.newsupper.bean;

import java.io.Serializable;

public class IBean implements Serializable {
	public static final int YES = 1;
	public static final int NO = 0;
}
