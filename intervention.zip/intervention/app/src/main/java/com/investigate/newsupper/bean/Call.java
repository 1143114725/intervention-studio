package com.investigate.newsupper.bean;

public interface Call {
	public void updateProgress(int curr, int total);
}
