package com.investigate.newsupper.bean;

import java.io.InputStream;

public class HttpBean {

	public int code;
	
	public InputStream inStream;
	
	public int contentLength;
}
