package com.investigate.newsupper.util;


public interface DialogListener {
	
	public void refreshActivity(Object object);

}
