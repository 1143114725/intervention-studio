package com.investigate.newsupper.bean;

public class LocLines {
	private String userId;
	private String surveyId;
	private String locLinesXml;
	public String getXml() {
		return locLinesXml;
	}

	public void setXml(String locLinesXml) {
		this.locLinesXml = locLinesXml;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getSurveyId() {
		// TODO Auto-generated method stub
		return surveyId;
	}

	public void setSurveyId(String surveyId) {
		this.surveyId = surveyId;
	}
	
}
