package com.investigate.newsupper.bean;
/**
 Created by EEH on 2018/9/17.
 */
public class DeletePanelBean {

    /**
     * state : 99
     * msg : 用户密码验证失败！
     */

    private String state;
    private String msg;

    public String getState() {

        return state;
    }

    public void setState(String state) {

        this.state = state;
    }

    public String getMsg() {

        return msg;
    }

    public void setMsg(String msg) {

        this.msg = msg;
    }
}
